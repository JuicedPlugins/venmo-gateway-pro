<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Parser\CommentStrategy;

use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\EmailLexer;
use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Result\Result;
use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Warning\Warning;

interface CommentStrategy
{
    /**
     * Return "true" to continue, "false" to exit
     */
    public function exitCondition(EmailLexer $lexer, int $openedParenthesis): bool;

    public function endOfLoopValidations(EmailLexer $lexer): Result;

    /**
     * @return Warning[]
     */
    public function getWarnings(): array;
}
