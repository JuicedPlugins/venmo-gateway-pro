<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Validation;

use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\EmailLexer;
use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\EmailParser;
use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Result\InvalidEmail;
use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Result\Reason\ExceptionFound;
use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Warning\Warning;

class RFCValidation implements EmailValidation
{
    /**
     * @var Warning[]
     */
    private array $warnings = [];

    /**
     * @var ?InvalidEmail
     */
    private $error;

    public function isValid(string $email, EmailLexer $emailLexer): bool
    {
        $parser = new EmailParser($emailLexer);
        try {
            $result = $parser->parse($email);
            $this->warnings = $parser->getWarnings();
            if ($result->isInvalid()) {
                /** @psalm-suppress PropertyTypeCoercion */
                $this->error = $result;
                return false;
            }
        } catch (\Exception $invalid) {
            $this->error = new InvalidEmail(new ExceptionFound($invalid), '');
            return false;
        }

        return true;
    }

    public function getError(): ?InvalidEmail
    {
        return $this->error;
    }

    /**
     * @return Warning[]
     */
    public function getWarnings(): array
    {
        return $this->warnings;
    }
}
