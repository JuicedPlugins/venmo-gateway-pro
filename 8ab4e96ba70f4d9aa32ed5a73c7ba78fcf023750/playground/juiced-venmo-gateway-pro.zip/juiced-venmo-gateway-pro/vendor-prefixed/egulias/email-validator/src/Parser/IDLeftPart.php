<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Parser;

use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Result\Result;
use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Result\InvalidEmail;
use JuicedPlugins\Venmo_Gateway_Pro\Egulias\EmailValidator\Result\Reason\CommentsInIDRight;

class IDLeftPart extends LocalPart
{
    protected function parseComments(): Result
    {
        return new InvalidEmail(new CommentsInIDRight(), $this->lexer->current->value);
    }
}
