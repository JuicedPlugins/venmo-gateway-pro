<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Psr\SimpleCache;

/**
 * Interface used for all types of exceptions thrown by the implementing library.
 */
interface CacheException extends \Throwable
{
}
