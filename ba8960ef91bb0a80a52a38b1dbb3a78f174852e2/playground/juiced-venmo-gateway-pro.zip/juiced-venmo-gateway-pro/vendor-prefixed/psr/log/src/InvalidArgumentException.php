<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
