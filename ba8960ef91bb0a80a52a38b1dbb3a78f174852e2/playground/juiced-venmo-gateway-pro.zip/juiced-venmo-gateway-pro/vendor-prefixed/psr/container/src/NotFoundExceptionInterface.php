<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Psr\Container;

/**
 * No entry was found in the container.
 */
interface NotFoundExceptionInterface extends ContainerExceptionInterface
{
}
