<?php
/**
 * Class QRCodeException
 *
 * @created      27.11.2015
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2015 Smiley
 * @license      MIT
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode;

use Exception;

/**
 * An exception container
 */
class QRCodeException extends Exception{

}
