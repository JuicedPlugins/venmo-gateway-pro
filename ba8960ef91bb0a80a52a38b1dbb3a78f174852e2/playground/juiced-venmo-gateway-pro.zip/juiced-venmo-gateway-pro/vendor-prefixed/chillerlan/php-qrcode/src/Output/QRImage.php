<?php
/**
 * Class QRImage
 *
 * @created      14.12.2021
 * @author       smiley <smiley@chillerlan.net>
 * @copyright    2021 smiley
 * @license      MIT
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\Output;

/**
 * @deprecated 5.0.0 backward compatibility, use QRGdImage instead
 * @see \JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\Output\QRGdImage
 */
class QRImage extends QRGdImage{

}
