<?php
/**
 * Class QRCodeDecoderException
 *
 * @created      01.12.2021
 * @author       smiley <smiley@chillerlan.net>
 * @copyright    2021 smiley
 * @license      MIT
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\Decoder;

use JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\QRCodeException;

/**
 * An exception container
 */
final class QRCodeDecoderException extends QRCodeException{

}
