<?php
/**
 * Class QROptions
 *
 * @created      08.12.2015
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2015 Smiley
 * @license      MIT
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode;

use JuicedPlugins\Venmo_Gateway_Pro\chillerlan\Settings\SettingsContainerAbstract;

/**
 * The QRCode settings container
 */
class QROptions extends SettingsContainerAbstract{
	use QROptionsTrait;
}
