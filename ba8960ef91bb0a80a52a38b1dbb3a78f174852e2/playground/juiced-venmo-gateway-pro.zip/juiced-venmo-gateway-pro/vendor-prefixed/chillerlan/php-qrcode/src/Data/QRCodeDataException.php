<?php
/**
 * Class QRCodeDataException
 *
 * @created      09.12.2015
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2015 Smiley
 * @license      MIT
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\Data;

use JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\QRCodeException;

/**
 * An exception container
 */
final class QRCodeDataException extends QRCodeException{

}
