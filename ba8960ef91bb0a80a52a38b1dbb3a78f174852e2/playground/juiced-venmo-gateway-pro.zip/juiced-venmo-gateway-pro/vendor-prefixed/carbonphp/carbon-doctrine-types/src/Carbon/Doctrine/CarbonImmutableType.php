<?php

declare(strict_types=1);

namespace JuicedPlugins\Venmo_Gateway_Pro\Carbon\Doctrine;

class CarbonImmutableType extends DateTimeImmutableType implements CarbonDoctrineType
{
}
