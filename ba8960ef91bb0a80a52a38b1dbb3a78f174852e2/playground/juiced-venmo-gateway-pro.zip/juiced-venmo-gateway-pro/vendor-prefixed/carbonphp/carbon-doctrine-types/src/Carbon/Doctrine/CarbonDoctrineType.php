<?php

declare(strict_types=1);

namespace JuicedPlugins\Venmo_Gateway_Pro\Carbon\Doctrine;

use JuicedPlugins\Venmo_Gateway_Pro\Carbon\CarbonInterface;
use Doctrine\DBAL\Platforms\AbstractPlatform;

interface CarbonDoctrineType
{
    public function getSQLDeclaration(array $fieldDeclaration, AbstractPlatform $platform): string;

    public function convertToPHPValue(mixed $value, AbstractPlatform $platform): ?CarbonInterface;

    public function convertToDatabaseValue(mixed $value, AbstractPlatform $platform): ?string;
}
