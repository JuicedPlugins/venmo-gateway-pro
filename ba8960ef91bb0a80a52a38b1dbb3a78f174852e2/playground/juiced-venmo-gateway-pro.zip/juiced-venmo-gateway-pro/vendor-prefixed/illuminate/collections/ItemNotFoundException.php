<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Support;

use RuntimeException;

class ItemNotFoundException extends RuntimeException
{
}
