<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Cache;

interface Factory
{
    /**
     * Get a cache store instance by name.
     *
     * @param  \UnitEnum|string|null  $name
     * @return \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Cache\Repository
     */
    public function store($name = null);
}
