<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Cache;

use Exception;

class LockTimeoutException extends Exception
{
    //
}
