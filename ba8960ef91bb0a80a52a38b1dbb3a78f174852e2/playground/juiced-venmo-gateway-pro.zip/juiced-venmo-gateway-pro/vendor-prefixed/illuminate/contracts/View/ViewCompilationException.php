<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\View;

use Exception;

class ViewCompilationException extends Exception
{
    //
}
