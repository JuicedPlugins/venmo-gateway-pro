<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Events;

interface ShouldDispatchAfterCommit
{
    //
}
