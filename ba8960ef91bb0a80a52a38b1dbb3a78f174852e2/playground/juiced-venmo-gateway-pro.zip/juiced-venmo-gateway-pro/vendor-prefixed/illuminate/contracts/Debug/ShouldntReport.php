<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Debug;

interface ShouldntReport
{
    //
}
