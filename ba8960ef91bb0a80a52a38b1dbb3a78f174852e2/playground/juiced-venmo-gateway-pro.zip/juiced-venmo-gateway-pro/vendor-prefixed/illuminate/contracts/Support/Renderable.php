<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Support;

interface Renderable
{
    /**
     * Get the evaluated contents of the object.
     *
     * @return string
     */
    public function render();
}
