<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Support;

interface MessageProvider
{
    /**
     * Get the messages for the instance.
     *
     * @return \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Support\MessageBag
     */
    public function getMessageBag();
}
