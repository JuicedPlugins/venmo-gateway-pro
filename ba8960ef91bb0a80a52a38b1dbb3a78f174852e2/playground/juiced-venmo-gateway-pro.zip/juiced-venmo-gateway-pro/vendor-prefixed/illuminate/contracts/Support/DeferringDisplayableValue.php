<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Support;

interface DeferringDisplayableValue
{
    /**
     * Resolve the displayable value that the class is deferring.
     *
     * @return \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Support\Htmlable|string
     */
    public function resolveDisplayableValue();
}
