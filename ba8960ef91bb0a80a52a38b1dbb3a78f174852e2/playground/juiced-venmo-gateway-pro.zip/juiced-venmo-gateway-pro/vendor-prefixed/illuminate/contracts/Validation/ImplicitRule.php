<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Validation;

/**
 * @deprecated see ValidationRule
 */
interface ImplicitRule extends Rule
{
    //
}
