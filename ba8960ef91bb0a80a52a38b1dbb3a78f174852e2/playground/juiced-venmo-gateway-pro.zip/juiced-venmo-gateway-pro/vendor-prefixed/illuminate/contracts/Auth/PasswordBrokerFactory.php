<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Auth;

interface PasswordBrokerFactory
{
    /**
     * Get a password broker instance by name.
     *
     * @param  string|null  $name
     * @return \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Auth\PasswordBroker
     */
    public function broker($name = null);
}
