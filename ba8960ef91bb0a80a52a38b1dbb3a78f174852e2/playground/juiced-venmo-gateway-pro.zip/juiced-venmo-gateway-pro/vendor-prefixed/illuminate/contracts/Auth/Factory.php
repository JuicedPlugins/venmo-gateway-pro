<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Auth;

interface Factory
{
    /**
     * Get a guard instance by name.
     *
     * @param  \UnitEnum|string|null  $name
     * @return \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Auth\Guard|\JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Auth\StatefulGuard
     */
    public function guard($name = null);

    /**
     * Set the default guard the factory should serve.
     *
     * @param  \UnitEnum|string|null  $name
     * @return void
     */
    public function shouldUse($name);
}
