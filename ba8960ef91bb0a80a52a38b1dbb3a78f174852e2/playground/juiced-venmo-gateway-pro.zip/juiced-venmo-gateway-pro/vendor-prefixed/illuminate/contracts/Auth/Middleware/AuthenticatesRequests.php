<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Auth\Middleware;

interface AuthenticatesRequests
{
    //
}
