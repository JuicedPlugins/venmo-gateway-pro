<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Filesystem;

use Exception;

class LockTimeoutException extends Exception
{
    //
}
