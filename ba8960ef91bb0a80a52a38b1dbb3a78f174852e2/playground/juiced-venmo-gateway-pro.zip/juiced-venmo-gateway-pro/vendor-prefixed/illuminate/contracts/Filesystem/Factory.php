<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Filesystem;

interface Factory
{
    /**
     * Get a filesystem implementation.
     *
     * @param  \UnitEnum|string|null  $name
     * @return \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Filesystem\Filesystem
     */
    public function disk($name = null);
}
