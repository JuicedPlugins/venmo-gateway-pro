<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Broadcasting;

interface ShouldBroadcastNow extends ShouldBroadcast
{
    //
}
