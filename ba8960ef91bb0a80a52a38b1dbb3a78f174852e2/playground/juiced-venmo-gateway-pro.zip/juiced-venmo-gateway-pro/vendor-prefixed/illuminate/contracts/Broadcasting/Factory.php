<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Broadcasting;

interface Factory
{
    /**
     * Get a broadcaster implementation by name.
     *
     * @param  string|null  $name
     * @return \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Broadcasting\Broadcaster
     */
    public function connection($name = null);
}
