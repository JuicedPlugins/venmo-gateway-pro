<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Log;

use JuicedPlugins\Venmo_Gateway_Pro\Monolog\Processor\ProcessorInterface;

interface ContextLogProcessor extends ProcessorInterface
{
}
