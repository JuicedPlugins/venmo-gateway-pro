<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Container;

interface ContextualAttribute
{
    //
}
