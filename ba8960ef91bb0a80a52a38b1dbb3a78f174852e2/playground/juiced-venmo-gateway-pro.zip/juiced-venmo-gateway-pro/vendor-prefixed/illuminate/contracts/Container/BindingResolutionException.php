<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Container;

use Exception;
use JuicedPlugins\Venmo_Gateway_Pro\Psr\Container\ContainerExceptionInterface;

class BindingResolutionException extends Exception implements ContainerExceptionInterface
{
    //
}
