<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Container;

use Exception;
use JuicedPlugins\Venmo_Gateway_Pro\Psr\Container\ContainerExceptionInterface;

class CircularDependencyException extends Exception implements ContainerExceptionInterface
{
    //
}
