<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Container;

/**
 * @method static static newInstance()
 */
interface SelfBuilding
{
}
