<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Image;

interface Transformation
{
    //
}
