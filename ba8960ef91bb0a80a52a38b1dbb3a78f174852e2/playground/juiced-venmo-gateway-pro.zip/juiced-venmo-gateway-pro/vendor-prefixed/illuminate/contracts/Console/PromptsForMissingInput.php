<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Console;

interface PromptsForMissingInput
{
    //
}
