<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Session\Middleware;

interface AuthenticatesSessions
{
    //
}
