<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Encryption;

use RuntimeException;

class EncryptException extends RuntimeException
{
    //
}
