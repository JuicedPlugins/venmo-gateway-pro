<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Encryption;

interface StringEncrypter
{
    /**
     * Encrypt a string without serialization.
     *
     * @param  string  $value
     * @return string
     *
     * @throws \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Encryption\EncryptException
     */
    public function encryptString(#[\SensitiveParameter] $value);

    /**
     * Decrypt the given string without unserialization.
     *
     * @param  string  $payload
     * @return string
     *
     * @throws \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Encryption\DecryptException
     */
    public function decryptString($payload);
}
