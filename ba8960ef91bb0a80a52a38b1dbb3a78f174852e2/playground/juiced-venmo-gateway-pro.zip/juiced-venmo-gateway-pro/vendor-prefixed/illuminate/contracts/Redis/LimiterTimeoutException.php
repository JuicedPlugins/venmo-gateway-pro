<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Redis;

use Exception;

class LimiterTimeoutException extends Exception
{
    //
}
