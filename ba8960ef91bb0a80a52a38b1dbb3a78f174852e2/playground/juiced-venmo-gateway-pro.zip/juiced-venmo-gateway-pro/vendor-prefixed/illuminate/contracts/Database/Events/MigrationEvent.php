<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Database\Events;

interface MigrationEvent
{
    //
}
