<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Database\Query;

interface ConditionExpression extends Expression
{
}
