<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Database\Eloquent;

use JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Database\Query\Builder as BaseContract;

/**
 * This interface is intentionally empty and exists to improve IDE support.
 *
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
interface Builder extends BaseContract
{
}
