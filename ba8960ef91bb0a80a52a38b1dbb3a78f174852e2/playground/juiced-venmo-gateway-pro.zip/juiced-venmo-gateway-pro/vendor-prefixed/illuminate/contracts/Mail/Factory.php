<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Mail;

interface Factory
{
    /**
     * Get a mailer instance by name.
     *
     * @param  \UnitEnum|string|null  $name
     * @return \JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Mail\Mailer
     */
    public function mailer($name = null);
}
