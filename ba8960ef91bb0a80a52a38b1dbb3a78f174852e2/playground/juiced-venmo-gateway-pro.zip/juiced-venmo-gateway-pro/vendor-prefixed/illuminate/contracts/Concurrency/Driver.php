<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Concurrency;

use JuicedPlugins\Venmo_Gateway_Pro\Carbon\CarbonInterval;
use Closure;
use JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Support\Defer\DeferredCallback;

interface Driver
{
    /**
     * Run the given tasks concurrently and return an array containing the results.
     */
    public function run(Closure|array $tasks, CarbonInterval|int|null $timeout = null): array;

    /**
     * Defer the execution of the given tasks.
     */
    public function defer(Closure|array $tasks): DeferredCallback;
}
