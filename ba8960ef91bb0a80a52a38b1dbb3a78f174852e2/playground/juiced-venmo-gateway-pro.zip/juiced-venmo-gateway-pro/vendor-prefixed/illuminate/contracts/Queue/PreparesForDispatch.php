<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Queue;

interface PreparesForDispatch
{
    /**
     * Run preparation logic before dispatch. Return false to abort.
     *
     * @return bool|void
     */
    public function prepareForDispatch();
}
