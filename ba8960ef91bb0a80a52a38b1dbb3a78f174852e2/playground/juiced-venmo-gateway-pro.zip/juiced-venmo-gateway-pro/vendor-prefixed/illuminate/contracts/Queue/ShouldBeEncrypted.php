<?php

namespace JuicedPlugins\Venmo_Gateway_Pro\Illuminate\Contracts\Queue;

interface ShouldBeEncrypted
{
    //
}
