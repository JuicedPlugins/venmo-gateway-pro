<?php
/**
 * Generates QR codes as base64-encoded data URIs.
 *
 * Shared by the WooCommerce and GiveWP integrations so the QR rendering options
 * (quiet-zone size, output type) live in one place.
 *
 * @package brianhenryie/juiced-venmo-gateway-pro
 */

declare(strict_types=1);

namespace JuicedPlugins\Venmo_Gateway_Pro\QR;

use JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\Output\QROutputInterface;
use JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\QRCode;
use JuicedPlugins\Venmo_Gateway_Pro\chillerlan\QRCode\QROptions;

/**
 * Wraps the chillerlan/php-qrcode library with the plugin's QR rendering defaults.
 */
class QR_Code {

	/**
	 * Render the given data as a QR code, returned as a base64-encoded data URI
	 * (e.g. `data:image/svg+xml;base64,…`) suitable for an `<img>` `src`.
	 *
	 * Returns an empty string when rendering fails (for example `GDIMAGE_PNG` on a
	 * host without the `gd` extension), so callers can degrade to a plain payment
	 * link rather than letting the exception fatal the page.
	 *
	 * @param string $data        The string to encode, e.g. a `venmo://` payment URL.
	 * @param string $output_type One of the {@see QROutputInterface} output-type constants.
	 *                            Defaults to SVG markup; pass `QROutputInterface::GDIMAGE_PNG`
	 *                            for contexts that cannot render inline SVG (e.g. email).
	 */
	public function get_data_uri( string $data, string $output_type = QROutputInterface::MARKUP_SVG ): string {

		$options = new QROptions(
			array(
				'quietzoneSize' => 1,
				'outputType'    => $output_type,
			)
		);

		try {
			return ( new QRCode( $options ) )->render( $data );
		} catch ( \Throwable $e ) {
			return '';
		}
	}
}
