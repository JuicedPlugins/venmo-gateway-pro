<?php
/**
 * Adds a "Mark paid" action to pending Venmo donations on the legacy
 * donations list table, opening a modal to record the payment details
 * (Venmo username, transaction id, payment date) before completing them.
 *
 * @package brianhenryie/juiced-venmo-gateway-pro
 */

declare(strict_types=1);

namespace JuicedPlugins\Venmo_Gateway_Pro\Integrations\GiveWP;

use JuicedPlugins\Venmo_Gateway_Pro\Venmo_Username;

/**
 * Adds the "Mark paid" modal workflow to the legacy donations list table.
 */
class Donations_List {

	const AJAX_ACTION  = 'venmo_mark_paid';
	const NONCE_ACTION = 'venmo_mark_paid';

	/**
	 * Append a "Mark paid" link beneath the status of pending Venmo donations
	 * in the Status column of the donations list table.
	 *
	 * @hooked give_payments_table_column
	 * @see \Give_Payment_History_Table::column_default()
	 *
	 * @param string $value       The rendered column HTML.
	 * @param int    $payment_id  The donation (payment) id for the row.
	 * @param string $column_name The column being rendered.
	 */
	public function add_mark_paid_link( string $value, int $payment_id, string $column_name ): string {
		if ( 'status' !== $column_name ) {
			return $value;
		}

		if ( Venmo_Gateway::id() !== give_get_payment_gateway( $payment_id ) ) {
			return $value;
		}

		if ( 'pending' !== give_get_payment_status( $payment_id ) ) {
			return $value;
		}

		if ( ! current_user_can( 'edit_give_payments' ) ) {
			return $value;
		}

		$link = sprintf(
			'<div class="row-actions"><span class="venmo-mark-paid-wrap"><a href="#" class="venmo-mark-paid" data-donation-id="%1$d">%2$s</a></span></div>',
			$payment_id,
			esc_html__( 'Mark paid', 'juiced-venmo-gateway-pro' )
		);

		return $value . $link;
	}

	/**
	 * Enqueue the modal script and styles on the donations list page only.
	 *
	 * @hooked admin_enqueue_scripts
	 * @see \do_action( 'admin_enqueue_scripts' )
	 *
	 * @param string $hook_suffix The current admin page.
	 */
	public function enqueue_assets( string $hook_suffix ): void {
		if ( ! $this->is_donations_list_page() ) {
			return;
		}

		wp_enqueue_style(
			'juiced-venmo-gateway-pro-donations-list',
			plugins_url( 'assets/givewp/donations-list.css', JUICED_VENMO_GATEWAY_PRO_FILE ),
			array(),
			JUICED_VENMO_GATEWAY_PRO_VERSION
		);

		wp_enqueue_script(
			'juiced-venmo-gateway-pro-donations-list',
			plugins_url( 'assets/givewp/donations-list.js', JUICED_VENMO_GATEWAY_PRO_FILE ),
			array(),
			JUICED_VENMO_GATEWAY_PRO_VERSION,
			true
		);

		wp_localize_script(
			'juiced-venmo-gateway-pro-donations-list',
			'venmomoMarkPaid',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'action'  => self::AJAX_ACTION,
				'nonce'   => wp_create_nonce( self::NONCE_ACTION ),
			)
		);
	}

	/**
	 * Print the (hidden) modal markup once in the admin footer of the list page.
	 *
	 * @hooked admin_footer
	 * @see \do_action( 'admin_footer' )
	 */
	public function render_modal(): void {
		if ( ! $this->is_donations_list_page() ) {
			return;
		}

		$today = current_time( 'Y-m-d' );
		?>
		<div id="venmo-mark-paid-modal" class="venmo-modal" hidden>
			<div class="venmo-modal__overlay" data-venmo-close></div>
			<div class="venmo-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="venmo-modal-title">
				<h2 id="venmo-modal-title"><?php esc_html_e( 'Mark Venmo donation paid', 'juiced-venmo-gateway-pro' ); ?></h2>
				<form id="venmo-mark-paid-form">
					<input type="hidden" name="donation_id" value="">
					<p>
						<label for="venmo-username"><?php esc_html_e( 'Venmo @username paid with', 'juiced-venmo-gateway-pro' ); ?></label>
						<input type="text" id="venmo-username" name="venmo_username" placeholder="@username">
					</p>
					<p>
						<label for="venmo_transaction_id"><?php esc_html_e( 'Transaction ID', 'juiced-venmo-gateway-pro' ); ?></label>
						<input type="text" id="venmo_transaction_id" name="transaction_id">
					</p>
					<p>
						<label for="venmo_payment_date"><?php esc_html_e( 'Payment date', 'juiced-venmo-gateway-pro' ); ?></label>
						<input type="date" id="venmo_payment_date" name="payment_date" value="<?php echo esc_attr( $today ); ?>">
					</p>
					<p>
						<label for="venmo-payment-time"><?php esc_html_e( 'Payment time', 'juiced-venmo-gateway-pro' ); ?></label>
						<input type="time" id="venmo-payment-time" name="payment_time">
					</p>
					<p class="venmo-modal__hint"><?php esc_html_e( 'All fields are optional.', 'juiced-venmo-gateway-pro' ); ?></p>
					<p class="venmo-modal__error" role="alert" hidden></p>
					<div class="venmo-modal__actions">
						<button type="button" class="button" data-venmo-close><?php esc_html_e( 'Cancel', 'juiced-venmo-gateway-pro' ); ?></button>
						<button type="submit" class="button button-primary"><?php esc_html_e( 'Mark paid', 'juiced-venmo-gateway-pro' ); ?></button>
					</div>
				</form>
			</div>
		</div>
		<?php
	}

	/**
	 * Record the (optional) payment details and mark the donation complete.
	 *
	 * @hooked wp_ajax_venmo_mark_paid
	 * @see \do_action( 'wp_ajax_venmo_mark_paid' )
	 */
	public function ajax_mark_paid(): void {
		check_ajax_referer( self::NONCE_ACTION, 'security' );

		if ( ! current_user_can( 'edit_give_payments' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to update donations.', 'juiced-venmo-gateway-pro' ) ),
				403
			);
		}

		$donation_id = isset( $_POST['donation_id'] ) ? absint( wp_unslash( $_POST['donation_id'] ) ) : 0;

		if ( 0 === $donation_id || Venmo_Gateway::id() !== give_get_payment_gateway( $donation_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Donation not found.', 'juiced-venmo-gateway-pro' ) ),
				404
			);
		}

		if ( 'pending' !== give_get_payment_status( $donation_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Only pending donations can be marked as paid.', 'juiced-venmo-gateway-pro' ) ),
				400
			);
		}

		$venmo_username = isset( $_POST['venmo_username'] ) ? sanitize_text_field( wp_unslash( $_POST['venmo_username'] ) ) : '';
		$transaction_id = isset( $_POST['transaction_id'] ) ? sanitize_text_field( wp_unslash( $_POST['transaction_id'] ) ) : '';
		$payment_date   = isset( $_POST['payment_date'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_date'] ) ) : '';
		$payment_time   = isset( $_POST['payment_time'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_time'] ) ) : '';

		// The time is optional; when given it is appended to the date (e.g. "2026-07-08 14:30").
		$payment_datetime = trim( $payment_date . ' ' . $payment_time );

		if ( '' !== $venmo_username ) {
			give_update_meta( $donation_id, Venmo_Gateway::CUSTOMER_VENMO_USERNAME_META_KEY, Venmo_Username::sanitize( $venmo_username ) );
		}
		if ( '' !== $transaction_id ) {
			give_update_meta( $donation_id, Venmo_Gateway::VENMO_TRANSACTION_ID_META_KEY, $transaction_id );
		}
		if ( '' !== $payment_datetime ) {
			give_update_meta( $donation_id, Venmo_Gateway::VENMO_PAYMENT_DATE_META_KEY, $payment_datetime );
		}

		give_insert_payment_note( $donation_id, $this->build_note( $venmo_username, $transaction_id, $payment_datetime ) );

		if ( ! give_update_payment_status( $donation_id, 'publish' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'The donation could not be marked as paid. Please try again.', 'juiced-venmo-gateway-pro' ) ),
				500
			);
		}

		wp_send_json_success(
			array(
				'donationId' => $donation_id,
				'status'     => give_get_payment_status( $donation_id, true ),
			)
		);
	}

	/**
	 * After a donation is marked paid (the modal redirects here with the id),
	 * show a success notice with the recorded details and a link to the single
	 * donation view so the admin knows which donation was updated.
	 *
	 * @hooked admin_notices
	 * @see \do_action( 'admin_notices' )
	 */
	public function admin_notice_marked_paid(): void {
		if ( ! $this->is_donations_list_page() || ! current_user_can( 'edit_give_payments' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display of an id passed on redirect.
		$donation_id = isset( $_GET['venmo-marked-paid'] ) ? absint( wp_unslash( $_GET['venmo-marked-paid'] ) ) : 0;

		if ( 0 === $donation_id || Venmo_Gateway::id() !== give_get_payment_gateway( $donation_id ) ) {
			return;
		}

		$view_url = add_query_arg(
			'id',
			$donation_id,
			admin_url( 'edit.php?post_type=give_forms&page=give-payment-history&view=view-payment-details' )
		);

		$username       = Venmo_Username::sanitize( (string) give_get_meta( $donation_id, Venmo_Gateway::CUSTOMER_VENMO_USERNAME_META_KEY, true ) );
		$transaction_id = (string) give_get_meta( $donation_id, Venmo_Gateway::VENMO_TRANSACTION_ID_META_KEY, true );
		$payment_date   = (string) give_get_meta( $donation_id, Venmo_Gateway::VENMO_PAYMENT_DATE_META_KEY, true );

		$details = array();
		if ( '' !== $username ) {
			/* translators: %s: Venmo @username */
			$details[] = sprintf( __( 'paid by @%s', 'juiced-venmo-gateway-pro' ), $username );
		}
		if ( '' !== $transaction_id ) {
			/* translators: %s: Venmo transaction id */
			$details[] = sprintf( __( 'transaction ID %s', 'juiced-venmo-gateway-pro' ), $transaction_id );
		}
		if ( '' !== $payment_date ) {
			/* translators: %s: payment date (and optional time) */
			$details[] = sprintf( __( 'payment date %s', 'juiced-venmo-gateway-pro' ), $payment_date );
		}

		$detail_text = empty( $details ) ? '' : ' — ' . implode( ', ', $details );

		?>
		<div class="notice notice-success is-dismissible">
			<p>
				<?php
				printf(
					/* translators: 1: donation id, 2: donation amount, 3: extra details (may be empty), 4: opening link tag, 5: closing link tag */
					esc_html__( 'Venmo donation #%1$d (%2$s) marked paid%3$s. %4$sView donation%5$s', 'juiced-venmo-gateway-pro' ),
					absint( $donation_id ),
					esc_html( give_donation_amount( $donation_id, true ) ),
					esc_html( $detail_text ),
					'<a href="' . esc_url( $view_url ) . '">',
					'</a>'
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Compose the donation note recording how the payment was confirmed.
	 *
	 * @param string $venmo_username   The Venmo @username the donor paid with.
	 * @param string $transaction_id   The Venmo transaction id.
	 * @param string $payment_datetime The date (and optional time) the payment was made.
	 */
	private function build_note( string $venmo_username, string $transaction_id, string $payment_datetime ): string {
		$note = __( 'Marked paid via Venmo.', 'juiced-venmo-gateway-pro' );

		if ( '' !== $venmo_username ) {
			/* translators: %s: Venmo @username */
			$note .= ' ' . sprintf( __( 'Paid by @%s.', 'juiced-venmo-gateway-pro' ), Venmo_Username::sanitize( $venmo_username ) );
		}
		if ( '' !== $transaction_id ) {
			/* translators: %s: Venmo transaction id */
			$note .= ' ' . sprintf( __( 'Transaction ID: %s.', 'juiced-venmo-gateway-pro' ), $transaction_id );
		}
		if ( '' !== $payment_datetime ) {
			/* translators: %s: payment date (and optional time) */
			$note .= ' ' . sprintf( __( 'Payment date: %s.', 'juiced-venmo-gateway-pro' ), $payment_datetime );
		}

		return $note;
	}

	/**
	 * Whether the current admin request is the legacy donations list page.
	 */
	private function is_donations_list_page(): bool {
		global $pagenow;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- reading a page identifier, not processing input.
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		return 'edit.php' === $pagenow && 'give-payment-history' === $page;
	}
}
