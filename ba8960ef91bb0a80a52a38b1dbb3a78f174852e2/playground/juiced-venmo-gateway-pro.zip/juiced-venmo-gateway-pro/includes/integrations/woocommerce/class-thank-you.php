<?php
/**
 * Instructions shown on the Thank You page immediately after the order is created.
 *
 * @package brianhenryie/juiced-venmo-gateway-pro
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\Integrations\WooCommerce;

use JuicedPlugins\Venmo_Gateway_Pro\QR\QR_Code;
use WC_Order;
use WC_Payment_Gateways;

/**
 * Adds Venmo payment instructions and a QR code to the WooCommerce order received (thank you) page.
 */
class Thank_You {

	/**
	 * Constructor.
	 *
	 * The `kses_allowed_protocols` filter is attached here, at plugin load, rather than on `init`, because
	 * {@see wp_allowed_protocols()} caches its result in a static variable the first time it is called (which
	 * can be earlier than `init`, e.g. via `sanitize_url()`). It is also only applied before `wp_loaded`.
	 */
	public function __construct() {
		add_filter( 'kses_allowed_protocols', array( $this, 'allow_data_protocol_for_inline_qr_code' ) );
	}

	/**
	 * Allow `data:` URIs on the thank you page so the inline QR code `<img src>` survives {@see wp_kses_post()}.
	 *
	 * @hooked kses_allowed_protocols
	 * @see wp_allowed_protocols()
	 *
	 * @param string[] $protocols Protocols allowed in HTML attributes.
	 *
	 * @return string[]
	 */
	public function allow_data_protocol_for_inline_qr_code( array $protocols ): array {
		if ( ! $this->is_thank_you_order_confirmation_page() ) {
			return $protocols;
		}

		return array_unique( array_merge( $protocols, array( 'data' ) ) );
	}

	/**
	 * Check for `/order-received/` in the URL.
	 *
	 * Must not call `sanitize_url()`/`esc_url()`: they call `wp_allowed_protocols()`, which runs the filter this
	 * is used in.
	 *
	 * TODO: How to confirm it without permalinks.
	 */
	protected function is_thank_you_order_confirmation_page(): bool {

		return isset( $_SERVER['REQUEST_URI'] ) && is_string( $_SERVER['REQUEST_URI'] ) &&
			str_contains( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), '/order-received/' );
	}

	/**
	 * Prints the HTML on the Thank You (post checkout) page.
	 *
	 * This hook is above the order details table.
	 *
	 * @hooked woocommerce_thankyou_order_received_text
	 *
	 * @param string    $thank_you_text "Your order has been received".
	 * @param ?WC_Order $order          The order, or null when WooCommerce could not load it.
	 */
	public function print_instructions( string $thank_you_text, ?WC_Order $order = null ): string {

		if ( ! ( $order instanceof WC_Order ) ) {
			return $thank_you_text;
		}

		$payment_gateways = WC_Payment_Gateways::instance()->payment_gateways();

		if ( ! isset( $payment_gateways[ $order->get_payment_method() ] ) ) {
			return $thank_you_text;
		}

		$payment_gateway_instance = $payment_gateways[ $order->get_payment_method() ];

		if ( ! ( $payment_gateway_instance instanceof Venmo_Gateway ) ) {
			return $thank_you_text;
		}

		// Thank you. Your order has been received.

		$customer_venmo_username = $order->get_meta( Venmo_Gateway::CUSTOMER_VENMO_USERNAME_META_KEY );
		$store_venmo_username    = $order->get_meta( Venmo_Gateway::STORE_VENMO_USERNAME_META_KEY );

		$order_id = $order->get_id();

		$payment_url_helper   = new Venmo_Payment_Url( $order );
		$venmo_payment_qr_url = $payment_url_helper->get_qr_url();
		$venmo_payment_url    = $payment_url_helper->get_browser_url();

		$venmo_logo_image_url = plugins_url( 'assets/woocommerce/images/venmo-logo-25.png', 'juiced-venmo-gateway-pro/juiced-venmo-gateway-pro.php' );
		$qr_code_data_base64  = ( new QR_Code() )->get_data_uri( $venmo_payment_qr_url );

		$order_total = " \${$order->get_total()}";

		// phpcs:ignore PluginCheck.CodeAnalysis.Heredoc.NotAllowed -- TODO: move this to a template.
		$instructions = <<<EOD
<br/>

<p><strong>Payment from @{$customer_venmo_username} to @{$store_venmo_username}</strong></p>

<p>Please send payment of <b>{$order_total}</b> via Venmo to <b><a target="_blank" href="{$venmo_payment_url}">@{$store_venmo_username}</b></a>.</p>

<p>Please pay the precise amount and include "<b>order {$order_id}</b>" in the note.</p>

<div style="text-align: center;">

	<div>
		<a target="_blank" href="{$venmo_payment_url}">
			<img src="{$venmo_logo_image_url}" />
		</a>
	</div>

	<div>
		<a target="_blank" href="{$venmo_payment_url}">
			<img style="display:block; max-height: 75vh; width: auto; max-width: 90vw; aspect-ratio: 1 / 1; margin: 0 auto;" src="{$qr_code_data_base64}" alt="Payment QR code" />
		</a>
	</div>

	<div>
		<a target="_blank" href="{$venmo_payment_url}">\${$order->get_total()} to @{$store_venmo_username}</a>
	</div>

</div>
EOD;

		$instructions .= '</p>';

		// Remove the last </p> because it is already contained in the HTML this string will be printed in.
		$instructions = substr( $instructions, 0, -4 );

		return $thank_you_text . '</p>' . wptexturize( $instructions );
	}
}
