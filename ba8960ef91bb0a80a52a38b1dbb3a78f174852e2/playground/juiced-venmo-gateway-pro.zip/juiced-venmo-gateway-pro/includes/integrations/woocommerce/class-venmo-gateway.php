<?php
/**
 *
 * @package brianhenryie/juiced-venmo-gateway-pro
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\Integrations\WooCommerce;

use JuicedPlugins\Venmo_Gateway_Pro\Psr\Log\LogLevel;
use JuicedPlugins\Venmo_Gateway_Pro\WP_Order_Email_Reconcile\API\Email_Reconciler;
use JuicedPlugins\Venmo_Gateway_Pro\WP_Order_Email_Reconcile\Integrations\WooCommerce\Credentials_Settings_Fields;
use JuicedPlugins\Venmo_Gateway_Pro\API\Settings;
use JuicedPlugins\Venmo_Gateway_Pro\API\Settings_Interface;
use JuicedPlugins\Venmo_Gateway_Pro\Venmo_Username;
use JuicedPlugins\Venmo_Gateway_Pro\Meta_Keys;
use WC_Order;
use WC_Payment_Gateway;

class Venmo_Gateway extends WC_Payment_Gateway {

	public $id = 'venmo';

	/**
	 * This is overwritten to add the destination account username.
	 *
	 * @see Payment_Gateways::format_admin_gateway_name()
	 */
	public $method_title = 'Venmo';

	public $title = 'Venmo';

	const CUSTOMER_VENMO_USERNAME_META_KEY = Meta_Keys::CUSTOMER_VENMO_USERNAME_META_KEY;

	/**
	 * The settings.store_venmo_username is saved to this order meta to know where we told the customer to pay.
	 */
	const STORE_VENMO_USERNAME_META_KEY = Meta_Keys::STORE_VENMO_USERNAME_META_KEY;

	/**
	 * Order meta key for the customer's full name as shown on their public Venmo profile, fetched in the
	 * background after checkout. Venmo's payment emails name the payer, not their username, so this is
	 * what a payment email can be matched against.
	 *
	 * @see Order::fetch_customer_venmo_profile()
	 */
	const CUSTOMER_VENMO_DISPLAY_NAME_META_KEY = Meta_Keys::CUSTOMER_VENMO_DISPLAY_NAME_META_KEY;

	/**
	 * @var Settings_Interface
	 */
	protected Settings_Interface $plugin_settings;

	public function __construct() {

		$this->plugin_settings = new Settings();

		$this->icon = plugins_url( 'assets/woocommerce/images/venmo-logo-25.png', 'juiced-venmo-gateway-pro/juiced-venmo-gateway-pro.php' );

		$this->has_fields = true;

		/**
		 * This is overwritten to add the destination account username.
		 *
		 * @see Venmo_Gateway::get_method_description()
		 */
		$this->method_description = 'Prompts the customer for their Venmo @username and instructs them to send payment the specified account.';

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		$this->description = $this->get_option( 'description' );

		// Save the wp-admin configuration form options.
		/** @phpstan-ignore return.void  */
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

		// Save the customer Venmo username to the order meta as the order is created (shortcode checkout).
		add_action( 'woocommerce_checkout_create_order', array( $this, 'save_order_payment_type_meta_data' ), 10, 2 );

		// Save the customer Venmo username for blocks checkout (Store API).
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'save_blocks_checkout_meta_data' ) );

		// When the gateway's settings are saved, update the plugin's log level to match.
		add_action( 'update_option_' . $this->get_option_key(), array( $this, 'update_plugin_log_level_on_settings_save' ), 10, 3 );

		$this->enabled = ( 'yes' === $this->enabled & $this->is_configured() ) ? 'yes' : 'no';
	}

	/**
	 * Check is the destination Venmo account username entered so the gateway is ready to use.
	 *
	 * @return bool
	 */
	public function is_configured(): bool {
		return ! empty( $this->get_option( 'store_venmo_username' ) );
	}

	/**
	 * The wp-admin configuration form.
	 */
	public function init_form_fields(): void {

		$store_venmo_username_description = '';

		$awaiting_payment_orders_url = ( new Orders_List_Filter() )->get_awaiting_payment_orders_url();

		$form_fields = array(
			'enabled'              => array(
				'title'       => __( 'Enable/Disable', 'juiced-venmo-gateway-pro' ),
				'type'        => 'checkbox',
				'label'       => __( 'Enable This Gateway', 'juiced-venmo-gateway-pro' ),
				'default'     => 'yes',
				'description' => '<a href="' . esc_url( $awaiting_payment_orders_url ) . '">' . __( 'View orders awaiting Venmo payment', 'juiced-venmo-gateway-pro' ) . '</a>',
				'desc_tip'    => false,
			),
			'title'                => array(
				'title'       => __( 'Title', 'juiced-venmo-gateway-pro' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'juiced-venmo-gateway-pro' ),
				'default'     => _x( 'Venmo', 'Method description here', 'juiced-venmo-gateway-pro' ),
				'desc_tip'    => true,
			),
			'description'          => array(
				'title'       => __( 'Description', 'juiced-venmo-gateway-pro' ),
				'type'        => 'text',
				'description' => __( 'Payment method description that the customer will see on your checkout.', 'juiced-venmo-gateway-pro' ) . " {$store_venmo_username_description}",
				'default'     => 'Use the Venmo app to pay for your order.',
				'desc_tip'    => true,
			),
			'store_venmo_username' => array(
				'title'       => __( 'Venmo Username', 'juiced-venmo-gateway-pro' ),
				'type'        => 'text',
				'description' => __( 'The venmo username whose account the customer will be instructed to pay.', 'juiced-venmo-gateway-pro' ),
				'desc_tip'    => false,
			),
		);

		// TODO: Display on settings page  (/add a link to show) what it will look like for the customer.

		$credentials_fields = new Credentials_Settings_Fields();
		$form_fields        = $credentials_fields->append_imap_reconcile_fields( $form_fields );

		/**
		 * The gateway's log level is shared with the entire plugin.
		 * When the gateway's settings are saved, the value is synced to `juiced_venmo_gateway_pro_log_level`.
		 * When the gateway's settings are loaded, the value is overwritten by `juiced_venmo_gateway_pro_log_level`
		 *
		 * @see self::update_plugin_log_level_on_settings_save()
		 * @see self::init_settings()
		 */
		$log_levels        = array( 'none', LogLevel::ERROR, LogLevel::WARNING, LogLevel::NOTICE, LogLevel::INFO, LogLevel::DEBUG );
		$log_levels_option = array();
		foreach ( $log_levels as $log_level ) {
			$log_levels_option[ $log_level ] = ucfirst( $log_level );
		}
		unset( $log_levels, $log_level );

		$form_fields['log_level'] = array(
			'title'       => __( 'Log Level', 'juiced-venmo-gateway-pro' ),
			'label'       => __( 'Enable Logging', 'juiced-venmo-gateway-pro' ),
			'type'        => 'select',
			'options'     => $log_levels_option,
			// TODO: if there is more than one instance, display a note saying "log level is common the the plugin not this specific instance".
			'description' => __( 'Increasingly detailed levels of logs. ', 'juiced-venmo-gateway-pro' ) . '<a href="' . admin_url( 'admin.php?page=juiced-venmo-gateway-pro-logs' ) . '">View Logs</a>',
			'desc_tip'    => false,
			'default'     => 'notice',
			'id'          => 'log_level',
		);

		$this->form_fields = $form_fields;
	}

	/**
	 * Use a shared `log_level` setting across the plugin – all instances across WooCommerce and GiveWP use the plugin's log level.
	 *
	 * @return void
	 */
	public function init_settings() {
		parent::init_settings();
		$log_levels = array( 'none', LogLevel::ERROR, LogLevel::WARNING, LogLevel::NOTICE, LogLevel::INFO, LogLevel::DEBUG );
		$log_level  = get_option( 'juiced_venmo_gateway_pro_log_level', $this->settings['log_level'] ?? 'notice' );

		if ( ! in_array( $log_level, $log_levels, true ) ) {
			$log_level = 'notice';
		}

		$this->settings['log_level'] = $log_level;
	}

	/**
	 * When settings are saved, update the plugin's log level.
	 *
	 * @hooked update_option_woocommerce_venmo_settings
	 * @see WC_Settings_API::update_option()
	 * @see update_option()
	 *
	 * @param mixed|array{log_level?:string} $old_value The existing wp_options value.
	 * @param mixed|array{log_level?:string} $value The value being saved.
	 * @param string                         $option Always "woocommerce_venmo_settings".
	 */
	public function update_plugin_log_level_on_settings_save( $old_value, $value, string $option ): void {
		if ( ! isset( $value['log_level'] ) ) {
			return;
		}

		if ( is_array( $old_value ) && isset( $old_value['log_level'] ) && $old_value['log_level'] === $value['log_level'] ) {
			return;
		}

		update_option( 'juiced_venmo_gateway_pro_log_level', $value['log_level'] );
	}

	/**
	 * The name of the checkout field for the customer's Venmo username, e.g. `venmo_customer_venmo_username`.
	 *
	 * It includes the gateway id, so each gateway instance (e.g. duplicates created with Duplicate Payment Gateways)
	 * has its own field in the shortcode checkout form. The blocks checkout sends it as payment data, which WooCommerce
	 * sets as `$_POST` for `validate_fields()`.
	 *
	 * @see \Automattic\WooCommerce\StoreApi\Legacy::process_legacy_payment()
	 * @see Venmo_Gateway_Blocks_Checkout_Support::get_payment_method_data()
	 */
	public function get_customer_venmo_username_field_name(): string {
		return $this->id . self::CUSTOMER_VENMO_USERNAME_META_KEY;
	}

	/**
	 * Frontend: prints the form displayed on the checkout.
	 * i.e. a simple HTML text input for the Venmo username.
	 */
	public function payment_fields(): void {

		// This just prints the description.
		parent::payment_fields();

		// Pre-populate with saved Venmo username.
		$customer_id = get_current_user_id();
		$value       = $this->get_saved_venmo_username( $customer_id );

		woocommerce_form_field(
			$this->get_customer_venmo_username_field_name(),
			array(
				'label'       => 'Enter your Venmo username:',
				'placeholder' => 'Venmo username',
				'maxlength'   => 255,
				'required'    => true,
			),
			$value
		);

		// Add JavaScript for focusing the field when Venmo is selected.
		$this->add_checkout_focus_script();
	}

	/**
	 * Server-side validation for the Venmo username field.
	 *
	 * @return bool True if validation passes.
	 */
	public function validate_fields(): bool {
		// @phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $_POST[ $this->get_customer_venmo_username_field_name() ] ) ) {
			wc_add_notice( __( 'Please enter your Venmo username.', 'juiced-venmo-gateway-pro' ), 'error' );
			return false;
		}

		return true;
	}

	/**
	 * Save the Venmo username as the order is created.
	 *
	 * @see woocommerce_checkout_update_order_meta
	 *
	 * @hooked woocommerce_checkout_create_order
	 * @see WC_Checkout::create_order()
	 * @see WC_Checkout::get_posted_data()
	 *
	 * @param WC_Order $order The newly created WooCommerce order.
	 * @param string[] $data
	 */
	public function save_order_payment_type_meta_data( WC_Order $order, array $data ): void {

		// Ignore-because: we're not processing data here.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( $data['payment_method'] !== $this->id || ! isset( $_POST[ $this->get_customer_venmo_username_field_name() ] ) ) {
			return;
		}

		// Ignore-because: this seems safe.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$customer_venmo_username = Venmo_Username::sanitize( sanitize_text_field( wp_unslash( $_POST[ $this->get_customer_venmo_username_field_name() ] ) ) );

		// Save Venmo username to order meta.
		$order->add_meta_data( self::CUSTOMER_VENMO_USERNAME_META_KEY, $customer_venmo_username, true );

		// Save Venmo username to customer usermeta if logged in.
		$customer_id = $order->get_customer_id();
		if ( $customer_id > 0 ) {
			update_user_meta( $customer_id, self::CUSTOMER_VENMO_USERNAME_META_KEY, $customer_venmo_username );
		} else {
			// Save Venmo username to cookie for guest users.
			$this->set_venmo_username_cookie( $customer_venmo_username );
		}

		$store_venmo_username = Venmo_Username::sanitize( $this->get_option( 'store_venmo_username' ) );
		$order->add_meta_data( self::STORE_VENMO_USERNAME_META_KEY, $store_venmo_username, true );

		$order->save();
	}

	/**
	 * Save the Venmo username from the blocks checkout (Store API).
	 *
	 * The blocks checkout sends payment method data via the Store API, which makes it
	 * available in the request body. This hook fires after the order is processed.
	 *
	 * @hooked woocommerce_store_api_checkout_order_processed
	 *
	 * @param WC_Order $order The WooCommerce order.
	 */
	public function save_blocks_checkout_meta_data( WC_Order $order ): void {

		if ( $order->get_payment_method() !== $this->id ) {
			return;
		}

		// Already saved by the shortcode checkout hook.
		if ( $order->meta_exists( self::CUSTOMER_VENMO_USERNAME_META_KEY ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$request_body = file_get_contents( 'php://input' );
		if ( ! $request_body ) {
			return;
		}

		$request_data = json_decode( $request_body, true );
		$payment_data = $request_data['payment_data'] ?? array();

		$customer_venmo_username = '';
		foreach ( $payment_data as $item ) {
			if ( isset( $item['key'] ) && $this->get_customer_venmo_username_field_name() === $item['key'] ) {
				$customer_venmo_username = Venmo_Username::sanitize( sanitize_text_field( $item['value'] ) );
				break;
			}
		}

		if ( empty( $customer_venmo_username ) ) {
			return;
		}

		// Save Venmo username to order meta.
		$order->add_meta_data( self::CUSTOMER_VENMO_USERNAME_META_KEY, $customer_venmo_username, true );

		// Save Venmo username to customer usermeta if logged in.
		$customer_id = $order->get_customer_id();
		if ( $customer_id > 0 ) {
			update_user_meta( $customer_id, self::CUSTOMER_VENMO_USERNAME_META_KEY, $customer_venmo_username );
		} else {
			// Save Venmo username to cookie for guest users.
			$this->set_venmo_username_cookie( $customer_venmo_username );
		}

		$store_venmo_username = Venmo_Username::sanitize( $this->get_option( 'store_venmo_username' ) );
		$order->add_meta_data( self::STORE_VENMO_USERNAME_META_KEY, $store_venmo_username, true );

		$order->save();
	}

	/**
	 * Strip any leading "@" from the store Venmo username when the settings are saved.
	 *
	 * WooCommerce calls `validate_{$key}_field` for the `store_venmo_username` field
	 * during `process_admin_options()`, so the value is stored as the bare handle.
	 *
	 * @see WC_Settings_API::get_field_value()
	 *
	 * @param string $key   The field key.
	 * @param string $value The submitted value.
	 */
	public function validate_store_venmo_username_field( string $key, string $value ): string {
		return Venmo_Username::sanitize( $this->validate_text_field( $key, $value ) );
	}

	/**
	 * On-Hold – Awaiting payment – stock is reduced, but you need to confirm payment.
	 *
	 * @see https://docs.woocommerce.com/document/managing-orders/
	 * @see Legacy::process_legacy_payment()
	 *
	 * @param int $order_id The (newly?) created order object whose payment status is about to be determined.
	 * @return string[]
	 */
	public function process_payment( $order_id ): array {

		$order = wc_get_order( $order_id );

		if ( ! ( $order instanceof WC_Order ) ) {
			// TODO: What are the correct return values for false|WC_Order_Refund?
			return array();
		}

		$customer_venmo_account    = $order->get_meta( self::CUSTOMER_VENMO_USERNAME_META_KEY, true );
		$destination_venmo_account = $order->get_meta( self::STORE_VENMO_USERNAME_META_KEY, true );

		/**
		 * Template: `https://venmo.com/{username}?txn=pay&amount={amount}&note={note}`.
		 */
		$venmo_payment_url = sprintf(
			'https://venmo.com/%s?txn=pay&amount=%s&note=%s',
			rawurlencode( $destination_venmo_account ),
			rawurlencode( $order->get_total() ),
			rawurlencode( 'order ' . $order_id )
		);

		$note = sprintf(
			'Awaiting Venmo payment of $%s from <a target="_blank" href="https://venmo.com/%s">@%s</a> to <a target="_blank" href="%s">@%s</a>.',
			$order->get_total(),
			$customer_venmo_account,
			$customer_venmo_account,
			$venmo_payment_url,
			$destination_venmo_account,
		);

		$order->update_status( 'on-hold', $note );

		// Reduce stock levels.
		wc_reduce_stock_levels( $order_id );

		// Empty cart.
		WC()->cart->empty_cart();

		// Redirect to Thank You page.
		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * Output the gateway settings screen.
	 *
	 * TODO: verify this is used or even doing anything different to the parent.
	 *
	 * Overrides the parents.
	 *
	 * @see WC_Payment_Gateway::admin_options()
	 * @see WC_Settings_API::admin_options()
	 */
	public function admin_options(): void {
		echo '<h2>' . esc_html( $this->get_method_title() );
		// No need to provide our own translation when a correct one exists.
		// phpcs:ignore WordPress.WP.I18n.TextDomainMismatch
		wc_back_link( __( 'Return to payments', 'woocommerce' ), admin_url( 'admin.php?page=wc-settings&tab=checkout' ) );
		echo '</h2>';
		echo wp_kses_post( wpautop( $this->get_method_description() ) );

		echo '<table class="form-table">';
		$this->generate_settings_html( $this->get_form_fields(), true );
		echo '</table>';
	}

	/**
	 * Return the gateway's title.
	 *
	 * This is displayed on the checkout to the customer.
	 * Also displayed on the admin order page.
	 *
	 * @see WC_Payment_Gateway::get_title()
	 *
	 * @return string
	 */
	public function get_title(): string {

		$title = $this->title;

		/**
		 * Hide the title "Venmo" or "venmo" at the checkout so only the logo image is displayed.
		 */
		if ( function_exists( 'is_checkout' ) && is_checkout() ) {
			$title = in_array( $title, array( 'Venmo', 'venmo' ), true )
				? ''
				: $title;
		}

		/**
		 * In admin order UI, show the username associated with the gateway.
		 * wp-admin/admin.php?page=wc-orders&action=edit&id=128
		 *
		 * TODO: This should really pull fom the order object iself, not the gateway. This block of code is in the wrong class.
		 *
		 * Order #128 details
		 * Payment via Venmo: @brianhenryie. Customer IP: 192.168.1.2
		 */
		if ( function_exists( 'get_current_screen' ) ) {
			global $pagenow;
			global $plugin_page;

			$store_venmo_username = $this->get_option( 'store_venmo_username' );

			if ( ! empty( $store_venmo_username ) && 'admin.php' === $pagenow && 'wc-orders' === $plugin_page ) {
				$title = "Venmo: @{$store_venmo_username}";
			}
		}

		return apply_filters( 'woocommerce_gateway_title', $title, $this->id );
	}

	/**
	 * Add the destination venmo username to the admin ui gateway title (particularly to distinguish multiple instances).
	 *
	 * TODO: The <i> are showing on the individual gateway settings page: /wp-admin/admin.php?page=wc-settings&tab=checkout&section=venmo
	 *
	 * @return string
	 */
	public function get_method_title() {
		$method_title = $this->method_title;

		$store_venmo_username = Venmo_Username::for_display( $this->get_option( 'store_venmo_username' ) );

		if ( '' === $store_venmo_username ) {
			return $method_title;
		}

		// Don't format it on the gateway's page itself.
		// Ignore-because: we're not actually processing data.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['tab'] ) && 'checkout' === $_GET['tab'] && ! isset( $_GET['section'] ) ) {
			$method_title = "{$method_title} – <i>{$store_venmo_username}</i>";
		} else {
			$method_title = "{$method_title} – {$store_venmo_username}";
		}

		/**
		 * Filter the method title.
		 *
		 * @param string             $title   Method title.
		 * @param WC_Payment_Gateway $gateway Payment gateway instance.
		 */
		return apply_filters( 'woocommerce_gateway_method_title', $method_title, $this );
	}

	/**
	 * Return the description for admin screens.
	 *
	 * E.g. Description column of WooCommerce/Settings/Payments.
	 *
	 * Overrides:
	 *
	 * @see WC_Payment_Gateway::get_method_description()
	 *
	 * @return string
	 */
	public function get_method_description(): string {

		$method_description = $this->method_description;

		$store_venmo_username = $this->get_option( 'store_venmo_username' );

		if ( ! empty( $store_venmo_username ) ) {

			$method_description = "Prompts the customer for their Venmo @username and instructs them to send payment to: <a href=\"https://venmo.com/{$store_venmo_username}\">@{$store_venmo_username}</a>";
		}
		return apply_filters( 'woocommerce_gateway_method_description', $method_description, $this );
	}

	/**
	 * Set a cookie with the Venmo username for guest users.
	 *
	 * @param string $venmo_username The Venmo username to save.
	 */
	protected function set_venmo_username_cookie( string $venmo_username ): void {
		if ( ! headers_sent() && ! empty( $venmo_username ) ) {
			$expiry = time() + ( constant( 'YEAR_IN_SECONDS' ) ); // 1 year expiry
			setcookie( 'venmo_username', $venmo_username, $expiry, '/', '', is_ssl(), true );
		}
	}

	/**
	 * Get the saved Venmo username from various sources.
	 *
	 * @param int|null $customer_id Optional customer ID.
	 * @return string The saved Venmo username or empty string.
	 */
	public function get_saved_venmo_username( ?int $customer_id = null ): string {
		// Try user meta if logged in.
		if ( $customer_id > 0 ) {
			$username = get_user_meta( $customer_id, self::CUSTOMER_VENMO_USERNAME_META_KEY, true );
			if ( ! empty( $username ) ) {
				return $username;
			}
		}

		// Try cookie for guests.
		if ( isset( $_COOKIE['venmo_username'] ) && is_string( $_COOKIE['venmo_username'] ) && '' !== $_COOKIE['venmo_username'] ) {
			return sanitize_text_field( wp_unslash( $_COOKIE['venmo_username'] ) );
		}

		// Fallback to previous order meta (if logged in).
		if ( $customer_id > 0 ) {
			/** @var WC_Order[] $orders */
			$orders = wc_get_orders(
				array(
					'customer_id'    => $customer_id,
					'payment_method' => $this->id,
					'limit'          => 1,
					'orderby'        => 'date',
					'order'          => 'DESC',
				)
			);

			if ( isset( $orders[0] ) ) {
				$username = (string) $orders[0]->get_meta( self::CUSTOMER_VENMO_USERNAME_META_KEY, true );
				if ( '' !== $username ) {
					return $username;
				}
			}
		}

		return '';
	}

	/**
	 * Add JavaScript for focusing the Venmo username field when needed.
	 */
	protected function add_checkout_focus_script(): void {
		?>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			// This gateway instance's id and username field, e.g. `venmo` and `#venmo_customer_venmo_username`.
			var gatewayId = '<?php echo esc_js( $this->id ); ?>';
			var usernameFieldSelector = '#<?php echo esc_js( $this->get_customer_venmo_username_field_name() ); ?>';

			// Focus username field when Venmo payment method is selected
			$(document.body).on('change', 'input[name="payment_method"]', function() {
				if ($(this).val() === gatewayId) {
					$(usernameFieldSelector).focus();
				}
			});

			// If Venmo is already selected on page load, focus the field
			if ($('input[name="payment_method"]:checked').val() === gatewayId) {
				setTimeout(function() {
					$(usernameFieldSelector).focus();
				}, 100);
			}

			// Focus username field on validation error
			$(document.body).on('checkout_error', function() {
				if ($('input[name="payment_method"]:checked').val() === gatewayId) {
					var $usernameField = $(usernameFieldSelector);
					if ($usernameField.length && $usernameField.val() === '') {
						$usernameField.focus();
					}
				}
			});
		});
		</script>
		<?php
	}

	/**
	 * Link the transaction id shown on the admin order screen ("Payment via Venmo (123)") to the transaction on venmo.com.
	 *
	 * The url is recorded on the order as `{prefix}transaction_url` by bh-wp-order-email-reconcile when the payment
	 * email is matched to the order; there is no url pattern to build one from the transaction id alone.
	 *
	 * @see WC_Payment_Gateway::get_transaction_url()
	 * @see \WC_Meta_Box_Order_Data::output()
	 * @see \JuicedPlugins\Venmo_Gateway_Pro\WP_Order_Email_Reconcile\API\Email_Reconciler::match_email_to_order()
	 *
	 * @param WC_Order $order The order.
	 * @return string The transaction url, or empty string.
	 */
	public function get_transaction_url( $order ) {
		$transaction_url = $order->get_meta( $this->get_order_meta_key( 'transaction_url' ) );

		return is_string( $transaction_url ) && '' !== $transaction_url
			? $transaction_url
			: parent::get_transaction_url( $order );
	}

	/**
	 * Prefix meta/option keys related to the gateway with the gateway id.
	 *
	 * Matches the keys bh-wp-order-email-reconcile records on the order when its payment email is matched.
	 *
	 * @see \JuicedPlugins\Venmo_Gateway_Pro\WP_Order_Email_Reconcile\API\Email_Reconciler::get_order_meta_key()
	 * @see Venmo_Gateway::get_transaction_url()
	 *
	 * Accidentally identical to {@see Email_Reconciler::get_order_meta_key()}.
	 *
	 * @param string $unprefixed The local meta key name.
	 */
	protected function get_order_meta_key( string $unprefixed ): string {
		return str_replace( '-', '_', sprintf( '%s_%s', $this->id, $unprefixed ) );
	}
}
