<?php
/**
 *
 * @package brianhenryie/juiced-venmo-gateway-pro
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\API;

use JuicedPlugins\Venmo_Gateway_Pro\WP_Order_Email_Reconcile\API\API as BH_WP_Order_Email_Reconcile;
use JuicedPlugins\Venmo_Gateway_Pro\WP_Order_Email_Reconcile\API\Unpaid_Orders_Provider_Interface;
use JuicedPlugins\Venmo_Gateway_Pro\Psr\Log\LoggerAwareTrait;
use JuicedPlugins\Venmo_Gateway_Pro\Psr\Log\LoggerInterface;

class API implements API_Interface {

	use LoggerAwareTrait;

	/**
	 * @param BH_WP_Order_Email_Reconcile $reconciler Instance of IMAP_Reconcile library to fetch emails and match with unpaid orders.
	 * @param Settings_Interface          $settings The plugin settings.
	 * @param LoggerInterface             $logger
	 */
	public function __construct(
		protected BH_WP_Order_Email_Reconcile $reconciler,
		protected Settings_Interface $settings,
		LoggerInterface $logger
	) {
		$this->logger = $logger;
	}

	/**
	 * Fetches emails from email servers for Venmo Gateways, parses them for payment data, reconciles with
	 * unpaid orders.
	 *
	 * @param ?int $since Unix time to check for emails since.
	 */
	public function check_for_payment_emails( $since = null ): void {

		// $this->imap->check_for_payment_emails( $since );
	}

	/**
	 * The reconcile library's aggregate provider of unpaid orders and donations.
	 *
	 * @see Unreconciled_Orders_Menu
	 */
	public function get_unpaid_orders_provider(): Unpaid_Orders_Provider_Interface {
		return $this->reconciler->get_unpaid_orders_provider();
	}

	/**
	 * Fetch a customer's public Venmo profile from `https://venmo.com/u/{username}`.
	 *
	 * @see Venmo_Profile_Fetcher
	 *
	 * @param string $username The Venmo username, with or without a leading `@`.
	 */
	public function get_venmo_profile( string $username ): ?Venmo_Profile {
		return ( new Venmo_Profile_Fetcher( $this->logger ) )->fetch( $username );
	}
}
