<?php
/**
 * @package brianhenryie/juiced-venmo-gateway-pro
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\API;

use JuicedPlugins\Venmo_Gateway_Pro\WP_Mailboxes\BH_WP_Mailboxes_Settings_Interface;
use JuicedPlugins\Venmo_Gateway_Pro\WP_Order_Email_Reconcile\Email_Extract_Settings_Interface;
use JuicedPlugins\Venmo_Gateway_Pro\WP_Order_Email_Reconcile\Email_Reconcile_Settings_Interface;
use JuicedPlugins\Venmo_Gateway_Pro\Integrations\WooCommerce\Venmo_Gateway;
use JuicedPlugins\Venmo_Gateway_Pro\Meta_Keys;
use JuicedPlugins\Venmo_Gateway_Pro\WP_Logger\Logger_Settings_Trait;
use JuicedPlugins\Venmo_Gateway_Pro\WP_Logger\WooCommerce_Logger_Settings_Interface;
use JuicedPlugins\Venmo_Gateway_Pro\WP_Mailboxes\BH_WP_Mailboxes_Settings_Defaults_Trait;
use JuicedPlugins\Venmo_Gateway_Pro\Psr\Log\LogLevel;
use WC_Payment_Gateways;

/**
 * Settings for the plugin's own classes, bh-wp-order-email-reconcile, and bh-wp-mailboxes.
 */
class Settings implements Settings_Interface, WooCommerce_Logger_Settings_Interface {
	use BH_WP_Mailboxes_Settings_Defaults_Trait, Logger_Settings_Trait {
		BH_WP_Mailboxes_Settings_Defaults_Trait::get_cli_base insteadof Logger_Settings_Trait;
		BH_WP_Mailboxes_Settings_Defaults_Trait::get_cli_base as mailboxes_cli_base;
		Logger_Settings_Trait::get_cli_base as logger_cli_base;
	}

	/**
	 * @see Logger_Settings_Interface
	 * @see IMAP_Reconcile_Settings_Interface
	 */
	public function get_plugin_slug(): string {
		return 'juiced-venmo-gateway-pro';
	}

	/**
	 * The log level for the plugin, configured on the WooCommerce gateway settings page.
	 *
	 * `wp option update juiced_venmo_gateway_pro_log_level`
	 *
	 * @see Venmo_Gateway::update_plugin_log_level_on_settings_save()
	 */
	public function get_log_level(): string {
		$log_levels      = array( 'none', LogLevel::DEBUG, LogLevel::INFO, LogLevel::NOTICE, LogLevel::WARNING, LogLevel::ERROR, LogLevel::CRITICAL, LogLevel::ALERT );
		$saved_log_level = get_option( 'juiced_venmo_gateway_pro_log_level', LogLevel::NOTICE );
		return in_array( $saved_log_level, $log_levels, true ) ? $saved_log_level : LogLevel::NOTICE;
	}

	/**
	 * This bool determines if the cron job is created (if absent) or deleted (if present).
	 *
	 * TODO: use the actual settings! (validate...)
	 * TODO: add filter.
	 */
	public function is_imap_reconcile_enabled(): bool {
		return true;
	}

	/**
	 * @see juiced-venmo-gateway-pro.php
	 * @see JUICED_VENMO_GATEWAY_PRO_VERSION
	 */
	public function get_plugin_version(): string {
		return '4.3.0';
	}

	/**
	 * TODO: This should be in the WooCommerce integration.
	 *
	 * @return string[]
	 */
	public function get_payment_method_ids(): array {

		// TODO: Can this be run before woocommerce_loaded?
		// If not?... cache it.
		// Print a warning in the logs.

		// if( ! did_action( 'woocommerce_payment_gateways' ) ) { return

		if ( class_exists( WC_Payment_Gateways::class ) ) {
			$gateway_subclasses = array();
			$payment_gateways   = WC_Payment_Gateways::instance()->payment_gateways();

			foreach ( $payment_gateways as $payment_gateway_instance ) {

				if ( $payment_gateway_instance instanceof Venmo_Gateway ) {

					$gateway_subclasses[] = $payment_gateway_instance->id;

				}
			}

			return $gateway_subclasses;
		} else {
			return array( 'venmo' );
		}
	}


	/**
	 * Name for the emails' custom post type, e.g. 'My Plugin Emails'.
	 *
	 * The trait converts this to 'venmo-payment-emails' / 'venmo_payment_emails' where appropriate,
	 * using `sanitize_title` and additionally `str_replace('-','_'...)` respectively.
	 *
	 * Should usually be one cpt per plugin. But there can be more than one mailbox per plugin.
	 * This should be hard-coded, and not derived from user input (e.g. mailbox name).
	 *
	 * Max. length 20 characters.
	 *
	 * @see BH_WP_Mailboxes_Settings_Interface::get_emails_cpt_friendly_name()
	 */
	public function get_emails_cpt_friendly_name(): string {
		return 'Venmo Payment Emails';
	}

	/**
	 * Display name for the email-accounts custom post type.
	 *
	 * Max. length 20 characters.
	 *
	 * @see BH_WP_Mailboxes_Settings_Interface::get_email_accounts_cpt_friendly_name()
	 */
	public function get_email_accounts_cpt_friendly_name(): string {
		return 'Venmo Email Accounts';
	}

	/**
	 * The regex patterns for parsing the emails.
	 *
	 * Multiple sets of patterns to extra data from the emails can be defined.
	 *
	 * TODO Filter
	 *
	 * @return Email_Extract_Settings_Interface[]
	 */
	public function get_patterns(): array {

		$patterns = array();

		$patterns[] = new Pattern_1();
		$patterns[] = new Pattern_2();
		$patterns[] = new Pattern_3();

		return $patterns;
	}

	/**
	 * Tell the IMAP reconcile how to find the customers' Venmo usernames.
	 */
	public function get_customer_payment_id_meta_key(): ?string {
		return Meta_Keys::CUSTOMER_VENMO_USERNAME_META_KEY;
	}

	/**
	 * Used on the logs page to show a nice name.
	 */
	public function get_plugin_name(): string {
		return 'Venmo Gateway';
	}

	/**
	 * Used in the logs library; used for `plugins.php` links.
	 */
	public function get_plugin_basename(): string {
		return defined( 'JUICED_VENMO_GATEWAY_PRO_BASENAME' ) && is_string( constant( 'JUICED_VENMO_GATEWAY_PRO_BASENAME' ) )
			? constant( 'JUICED_VENMO_GATEWAY_PRO_BASENAME' )
			: 'juiced-venmo-gateway-pro/juiced-venmo-gateway-pro.php';
	}

	/**
	 * Email attachments are not saved. The payment emails' text is all that is needed for reconciling.
	 *
	 * Null disables bh-wp-private-uploads in bh-wp-mailboxes.
	 *
	 * @see BH_WP_Mailboxes_Settings_Interface::get_private_uploads_directory_name()
	 */
	public function get_private_uploads_directory_name(): ?string {
		return null;
	}

	/**
	 * @see BH_WP_Mailboxes_Settings_Interface::get_rest_namespace()
	 */
	public function get_rest_namespace(): ?string {
		return 'juiced-venmo-gateway-pro';
	}
}
