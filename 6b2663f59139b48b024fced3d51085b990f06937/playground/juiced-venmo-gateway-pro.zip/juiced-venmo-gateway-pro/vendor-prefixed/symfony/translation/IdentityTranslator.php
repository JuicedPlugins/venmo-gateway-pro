<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace JuicedPlugins\Venmo_Gateway_Pro\Symfony\Component\Translation;

use JuicedPlugins\Venmo_Gateway_Pro\Symfony\Contracts\Translation\LocaleAwareInterface;
use JuicedPlugins\Venmo_Gateway_Pro\Symfony\Contracts\Translation\TranslatorInterface;
use JuicedPlugins\Venmo_Gateway_Pro\Symfony\Contracts\Translation\TranslatorTrait;

/**
 * IdentityTranslator does not translate anything.
 *
 * @author Fabien Potencier <fabien@symfony.com>
 */
class IdentityTranslator implements TranslatorInterface, LocaleAwareInterface
{
    use TranslatorTrait;

    public function setLocale(string $locale): void
    {
        $this->locale = $locale;
    }
}
