<?php return array (
  'root' => 
  array (
    'name' => 'brianhenryie/juiced-venmo-gateway-pro',
    'pretty_version' => 'dev-d3c0998c6212d2a56eabde7cd8ad4d7ecf84489e',
    'version' => 'dev-d3c0998c6212d2a56eabde7cd8ad4d7ecf84489e',
    'reference' => 'd3c0998c6212d2a56eabde7cd8ad4d7ecf84489e',
    'type' => 'wordpress-plugin',
    'install_path' => __DIR__ . '/../',
    'aliases' => 
    array (
    ),
    'dev' => true,
  ),
  'versions' => 
  array (
    'alleyinteractive/wordpress-autoloader' => 
    array (
      'pretty_version' => 'v1.2.1',
      'version' => '1.2.1.0',
      'reference' => '570a0e911f806448d2709864729a53731c49fcd9',
      'type' => 'library',
      'install_path' => __DIR__ . '/../alleyinteractive/wordpress-autoloader',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wc-logger' => 
    array (
      'pretty_version' => '0.2',
      'version' => '0.2.0.0',
      'reference' => 'c2288a5c9a4a59a0890f5c09f06d260381b1c78f',
      'type' => 'library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wc-logger',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wp-cli-logger' => 
    array (
      'pretty_version' => 'v2.0.0',
      'version' => '2.0.0.0',
      'reference' => '54f0aaa23b99f3983c18b8b42d29702c9130ba9d',
      'type' => 'library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wp-cli-logger',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wp-logger' => 
    array (
      'pretty_version' => '0.5.0',
      'version' => '0.5.0.0',
      'reference' => '40ef62c20cad114bc8ef76fbf3a5ebf1e8cc6035',
      'type' => 'library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wp-logger',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wp-mailboxes' => 
    array (
      'pretty_version' => 'dev-master',
      'version' => 'dev-master',
      'reference' => 'd4d455ac536bdb939df52ce004c5706d1100a688',
      'type' => 'library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wp-mailboxes',
      'aliases' => 
      array (
        0 => '9999999-dev',
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wp-order-email-reconcile' => 
    array (
      'pretty_version' => 'dev-master',
      'version' => 'dev-master',
      'reference' => 'beada1036ae4455401164cc8aad7ead32e84a590',
      'type' => 'wordpress-library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wp-order-email-reconcile',
      'aliases' => 
      array (
        0 => '9999999-dev',
      ),
      'dev_requirement' => false,
    ),
    'brianhenryie/bh-wp-private-uploads' => 
    array (
      'pretty_version' => '0.5.1',
      'version' => '0.5.1.0',
      'reference' => '06d92a3f1a3be79ccff96181c9109007cfb63899',
      'type' => 'library',
      'install_path' => __DIR__ . '/../brianhenryie/bh-wp-private-uploads',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'carbonphp/carbon-doctrine-types' => 
    array (
      'pretty_version' => '3.2.1',
      'version' => '3.2.1.0',
      'reference' => '5fa5eacafd9ef47c8c6ab9143fc901ba0194d3dc',
      'type' => 'library',
      'install_path' => __DIR__ . '/../carbonphp/carbon-doctrine-types',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'chillerlan/php-qrcode' => 
    array (
      'pretty_version' => '5.0.5',
      'version' => '5.0.5.0',
      'reference' => '7b66282572fc14075c0507d74d9837dab25b38d6',
      'type' => 'library',
      'install_path' => __DIR__ . '/../chillerlan/php-qrcode',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'chillerlan/php-settings-container' => 
    array (
      'pretty_version' => '3.3.0',
      'version' => '3.3.0.0',
      'reference' => 'a0a487cbf5344f721eb504bf0f59bada40c381b7',
      'type' => 'library',
      'install_path' => __DIR__ . '/../chillerlan/php-settings-container',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'directorytree/imapengine' => 
    array (
      'pretty_version' => 'v1.25.6',
      'version' => '1.25.6.0',
      'reference' => '20655ae7dbe045a64d6c72237ee5ae322af49f67',
      'type' => 'library',
      'install_path' => __DIR__ . '/../directorytree/imapengine',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'doctrine/lexer' => 
    array (
      'pretty_version' => '3.0.3',
      'version' => '3.0.3.0',
      'reference' => '71d305eaa6480d3d3460c7d053d1da7749fa9cca',
      'type' => 'library',
      'install_path' => __DIR__ . '/../doctrine/lexer',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'egulias/email-validator' => 
    array (
      'pretty_version' => '4.0.4',
      'version' => '4.0.4.0',
      'reference' => 'd42c8731f0624ad6bdc8d3e5e9a4524f68801cfa',
      'type' => 'library',
      'install_path' => __DIR__ . '/../egulias/email-validator',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'guzzlehttp/psr7' => 
    array (
      'pretty_version' => '2.13.1',
      'version' => '2.13.1.0',
      'reference' => '95e7828100de18b4e269fb1703be530082d5166d',
      'type' => 'library',
      'install_path' => __DIR__ . '/../guzzlehttp/psr7',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'illuminate/collections' => 
    array (
      'pretty_version' => 'v13.35.0',
      'version' => '13.35.0.0',
      'reference' => '6eebd20c5ec8958a782008aea1374e9600cf8135',
      'type' => 'library',
      'install_path' => __DIR__ . '/../illuminate/collections',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'illuminate/conditionable' => 
    array (
      'pretty_version' => 'v13.35.0',
      'version' => '13.35.0.0',
      'reference' => '7f1ef52d9a346f829421b296adfb7644a951b216',
      'type' => 'library',
      'install_path' => __DIR__ . '/../illuminate/conditionable',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'illuminate/contracts' => 
    array (
      'pretty_version' => 'v13.35.0',
      'version' => '13.35.0.0',
      'reference' => '0cabe75392aad93ac739bbb220a3f5d943b12b30',
      'type' => 'library',
      'install_path' => __DIR__ . '/../illuminate/contracts',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'illuminate/macroable' => 
    array (
      'pretty_version' => 'v13.35.0',
      'version' => '13.35.0.0',
      'reference' => '59b5b5f3cf290a91db8cf6cd3d35ff56978bc057',
      'type' => 'library',
      'install_path' => __DIR__ . '/../illuminate/macroable',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'laravel/serializable-closure' => 
    array (
      'pretty_version' => 'v2.1.0',
      'version' => '2.1.0.0',
      'reference' => '2d5869a838bbcf37e0d8b0568fc41914e81374b5',
      'type' => 'library',
      'install_path' => __DIR__ . '/../laravel/serializable-closure',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'monolog/monolog' => 
    array (
      'pretty_version' => '3.12.1',
      'version' => '3.12.1.0',
      'reference' => 'd7059e4c691d05ea1222b5124bed0f961be46e15',
      'type' => 'library',
      'install_path' => __DIR__ . '/../monolog/monolog',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'nesbot/carbon' => 
    array (
      'pretty_version' => '3.14.2',
      'version' => '3.14.2.0',
      'reference' => '94cfc34887f07ab5c0efa07914c8f527544e3224',
      'type' => 'library',
      'install_path' => __DIR__ . '/../nesbot/carbon',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'php-di/invoker' => 
    array (
      'pretty_version' => '2.3.7',
      'version' => '2.3.7.0',
      'reference' => '3c1ddfdef181431fbc4be83378f6d036d59e81e1',
      'type' => 'library',
      'install_path' => __DIR__ . '/../php-di/invoker',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'php-di/php-di' => 
    array (
      'pretty_version' => '7.1.1',
      'version' => '7.1.1.0',
      'reference' => 'f88054cc052e40dbe7b383c8817c19442d480352',
      'type' => 'library',
      'install_path' => __DIR__ . '/../php-di/php-di',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/clock' => 
    array (
      'pretty_version' => '1.0.0',
      'version' => '1.0.0.0',
      'reference' => 'e41a24703d4560fd0acb709162f73b8adfc3aa0d',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/clock',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/container' => 
    array (
      'pretty_version' => '2.0.2',
      'version' => '2.0.2.0',
      'reference' => 'c71ecc56dfe541dbd90c5360474fbc405f8d5963',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/container',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/http-factory' => 
    array (
      'pretty_version' => '1.1.0',
      'version' => '1.1.0.0',
      'reference' => '2b4765fddfe3b508ac62f829e852b1501d3f6e8a',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/http-factory',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/http-message' => 
    array (
      'pretty_version' => '2.0',
      'version' => '2.0.0.0',
      'reference' => '402d35bcb92c70c026d1a6a9883f06b2ead23d71',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/http-message',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/log' => 
    array (
      'pretty_version' => '3.0.2',
      'version' => '3.0.2.0',
      'reference' => 'f16e1d5863e37f8d8c2a01719f5b34baa2b714d3',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/log',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'psr/simple-cache' => 
    array (
      'pretty_version' => '3.0.0',
      'version' => '3.0.0.0',
      'reference' => '764e0b3939f5ca87cb904f570ef9be2d78a07865',
      'type' => 'library',
      'install_path' => __DIR__ . '/../psr/simple-cache',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'ralouphie/getallheaders' => 
    array (
      'pretty_version' => '3.0.3',
      'version' => '3.0.3.0',
      'reference' => '120b605dfeb996808c31b6477290a714d356e822',
      'type' => 'library',
      'install_path' => __DIR__ . '/../ralouphie/getallheaders',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/clock' => 
    array (
      'pretty_version' => 'v8.0.8',
      'version' => '8.0.8.0',
      'reference' => 'b55a638b189a6faa875e0ccdb00908fb87af95b3',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/clock',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/deprecation-contracts' => 
    array (
      'pretty_version' => 'v3.7.1',
      'version' => '3.7.1.0',
      'reference' => 'f3202fa1b5097b0af062dc978b32ecf63404e31d',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/deprecation-contracts',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/mime' => 
    array (
      'pretty_version' => 'v8.0.15',
      'version' => '8.0.15.0',
      'reference' => '330d91f5ecb712de40f6646f1537ca11ad555981',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/mime',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-iconv' => 
    array (
      'pretty_version' => 'v1.43.0',
      'version' => '1.43.0.0',
      'reference' => '254724d95fe01b679cd97d88786e9623ee00bfb7',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-iconv',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-intl-idn' => 
    array (
      'pretty_version' => 'v1.43.0',
      'version' => '1.43.0.0',
      'reference' => '533d68cf99c8f8ee2e8893c59ed59192e92cfd74',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-intl-idn',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-intl-normalizer' => 
    array (
      'pretty_version' => 'v1.43.0',
      'version' => '1.43.0.0',
      'reference' => 'ebd57ccc7edb93d632e184efbe7693d2517bab3b',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-intl-normalizer',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-mbstring' => 
    array (
      'pretty_version' => 'v1.43.0',
      'version' => '1.43.0.0',
      'reference' => '4d5d331bf731e0aedbc6b2f5e61135b7b7996a72',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-mbstring',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-php80' => 
    array (
      'pretty_version' => 'v1.43.0',
      'version' => '1.43.0.0',
      'reference' => '9c6a5d6b01ca51d486c813e9a9c0ed55f208bb74',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-php80',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-php84' => 
    array (
      'pretty_version' => 'v1.43.0',
      'version' => '1.43.0.0',
      'reference' => '22c6548499cbe5c5bb072fc0c42312dff062a015',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-php84',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-php85' => 
    array (
      'pretty_version' => 'v1.43.0',
      'version' => '1.43.0.0',
      'reference' => '86a42cbcc07adc331481a5ab310a4024bfc227f6',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-php85',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/polyfill-php86' => 
    array (
      'pretty_version' => 'v1.43.0',
      'version' => '1.43.0.0',
      'reference' => '8840df45b24f33a49dc419fa18dc0057231ae1d8',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/polyfill-php86',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/translation' => 
    array (
      'pretty_version' => 'v8.0.14',
      'version' => '8.0.14.0',
      'reference' => '319ee314b21ddc0404f12fb16935f85b8a3520b6',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/translation',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'symfony/translation-contracts' => 
    array (
      'pretty_version' => 'v3.7.1',
      'version' => '3.7.1.0',
      'reference' => 'ccb206b98faccc511ebae8e5fad50f2dc0b30621',
      'type' => 'library',
      'install_path' => __DIR__ . '/../symfony/translation-contracts',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'wordpress/secrets-api' => 
    array (
      'pretty_version' => 'dev-main',
      'version' => 'dev-main',
      'reference' => 'eac860bab9b3600cc8371179c1e01e6058a63c8c',
      'type' => 'wordpress-plugin',
      'install_path' => __DIR__ . '/../wordpress/secrets-api',
      'aliases' => 
      array (
        0 => '9999999-dev',
      ),
      'dev_requirement' => false,
    ),
    'wptrt/admin-notices' => 
    array (
      'pretty_version' => 'v1.0.4',
      'version' => '1.0.4.0',
      'reference' => '1df860950b4198cc93e867873b1b571b51f908b0',
      'type' => 'library',
      'install_path' => __DIR__ . '/../wptrt/admin-notices',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'zbateson/mail-mime-parser' => 
    array (
      'pretty_version' => '4.0.6',
      'version' => '4.0.6.0',
      'reference' => 'f7d3c271536a8b3d50dc3a942de8f56282629bb8',
      'type' => 'library',
      'install_path' => __DIR__ . '/../zbateson/mail-mime-parser',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'zbateson/mb-wrapper' => 
    array (
      'pretty_version' => '3.0.1',
      'version' => '3.0.1.0',
      'reference' => '36dd227ed698d9f5fe995ea75dbcc594a2d880bb',
      'type' => 'library',
      'install_path' => __DIR__ . '/../zbateson/mb-wrapper',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
    'zbateson/stream-decorators' => 
    array (
      'pretty_version' => '3.0.2',
      'version' => '3.0.2.0',
      'reference' => '4776323764ec592de417ef54f3c8fc96fd242849',
      'type' => 'library',
      'install_path' => __DIR__ . '/../zbateson/stream-decorators',
      'aliases' => 
      array (
      ),
      'dev_requirement' => false,
    ),
  ),
);